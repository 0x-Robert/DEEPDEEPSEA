﻿using System.Collections;
using UnityEngine;



public class DestroyObject : MonoBehaviour {
	public void DestroyEvent() {
		Destroy (gameObject); 
	}
}